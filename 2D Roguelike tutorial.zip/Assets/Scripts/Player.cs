﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour {
    
    public  float smoothing = 1;
    public float restTime = 1;
    public float restTimer = 0;
    private Rigidbody2D playerRigidbody;
    private Vector2 targetPos = new Vector2(1,1);
    private BoxCollider2D collider1;
    // Use this for initialization
    void Start () {
        playerRigidbody = GetComponent<Rigidbody2D>();
        collider1 = GetComponent<BoxCollider2D>();
    }
	
	// Update is called once per frame
	void Update () {
        playerRigidbody.MovePosition(Vector2.Lerp(transform.position, targetPos, smoothing * Time.deltaTime));
        restTimer += Time.deltaTime;
        if (restTimer < restTime) return; 
        
        float h = Input.GetAxisRaw("Horizontal");
        float v = Input.GetAxisRaw("Vertical"); 
        if (h > 0) {
            v = 0;
        }
        if (h != 0 || v != 0)
        {
            //碰撞检测
            collider1.enabled = false;
            RaycastHit2D hit = Physics2D.Linecast(targetPos, targetPos + new Vector2(h, v));
            collider1.enabled = true;
            if (hit.transform == null)
            {
                targetPos += new Vector2(h, v);

                restTimer = 0;
            }
        }
	}
}
