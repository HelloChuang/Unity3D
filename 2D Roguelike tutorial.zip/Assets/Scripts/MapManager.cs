﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MapManager : MonoBehaviour {
    public GameObject[] outWallArray;
    public GameObject[] floorArray;
    public GameObject[] wallArray;
    public GameObject[] foodArray;
    public GameObject[] enemyArray;
    public GameObject exitPrefab;

    private GameManager gameManager;

    public int rows=10;
    public int cols=10;

    public int minCountWall = 2;
    public int maxCountWall = 8;

    private Transform mapHolder;
    private List<Vector2> positionList = new List<Vector2>();  //存放位置信息
	// Use this for initialization
	void Awake () {
        gameManager = this.GetComponent<GameManager>();
        InitMap();
	}
	
	// Update is called once per frame
	void Update () {
		
	}

    private void  InitMap() {
        //创建地板和障碍物
        mapHolder = new GameObject("Map").transform;
        for (int x = 0; x < cols; x++) {
            for (int y=0;y<rows;y++) {
                if (x == 0 || y == 0 || x == cols - 1 || y == rows - 1)
                {
                    int index = Random.Range(0, outWallArray.Length);
                    GameObject go = GameObject.Instantiate(outWallArray[index], new Vector3(x, y, 0), Quaternion.identity) as GameObject;
                    go.transform.SetParent(mapHolder);
                }
                else {
                    int index2 = Random.Range(0,floorArray.Length);
                    GameObject go = GameObject.Instantiate(floorArray[index2],new Vector3(x,y,0),Quaternion.identity) as GameObject;
                    go.transform.SetParent(mapHolder);
                }
            }
        }
        //创建食物障碍物僵尸
        positionList.Clear();
        for (int x = 2; x < cols-2; x++)
        {
            for (int y = 2; y < rows - 2; y++)
            {
                positionList.Add(new Vector2(x, y));
            }
        }
        int wallCount = Random.Range(minCountWall, maxCountWall + 1);//障碍物个数
        InstantiateItems(wallCount, wallArray);
        //生成食物2-leavl*2
        int foodCount = Random.Range(0,gameManager.level*2+1);
        InstantiateItems(foodCount, foodArray); 
        //创建敌人level/2;
        int enemyCount = gameManager.level / 2;
        InstantiateItems(enemyCount,enemyArray); 
        //创建出口
        GameObject go4 =  GameObject.Instantiate(exitPrefab,new Vector2(cols-2,rows-2),Quaternion.identity )as GameObject;
        go4.transform.SetParent(mapHolder);

        
    }
    private void InstantiateItems(int count,GameObject[] prefabs) {
        for (int i = 0; i < count ; i++)
        {
            Vector2 pos = RandomPosition();
            GameObject enemyPrefab = RandomPrefab(prefabs);
            GameObject go = GameObject.Instantiate(enemyPrefab, pos, Quaternion.identity) as GameObject;
            go.transform.SetParent(mapHolder);
        }
    }

    private Vector2 RandomPosition() {
        int positionIndex = Random.Range(0, positionList.Count);//随机生成位置
        Vector2 pos = positionList[positionIndex];//取得该位置
        positionList.RemoveAt(positionIndex);//移除该位置的索引，保证只生成一次
        return pos;
    }
    private GameObject RandomPrefab(GameObject[] prefabs) {
        int index = Random.Range(0,prefabs.Length);
        return prefabs[index];

    }
}
